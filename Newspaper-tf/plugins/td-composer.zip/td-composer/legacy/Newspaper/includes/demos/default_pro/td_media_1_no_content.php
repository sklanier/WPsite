<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_x', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/footer_bg.jpg');