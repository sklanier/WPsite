<?php
td_demo_media::add_image_to_media_gallery('td_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/9.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/10.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_11', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/11.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_12', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/12.jpg');

