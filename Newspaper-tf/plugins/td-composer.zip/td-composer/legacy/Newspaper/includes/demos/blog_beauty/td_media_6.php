<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/blog_beauty/logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_footer',             "http://demo_content.tagdiv.com/Newspaper_6/blog_beauty/logo_other.png");


// other images
td_demo_media::add_image_to_media_gallery('td_pic_about',               "http://demo_content.tagdiv.com/Newspaper_6/blog_beauty/about.jpg");