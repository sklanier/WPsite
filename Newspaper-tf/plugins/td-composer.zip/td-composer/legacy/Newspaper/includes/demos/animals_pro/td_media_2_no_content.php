<?php

// ads
td_demo_media::add_image_to_media_gallery('td_reclama_1',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/reclama1.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama_2',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/reclama2.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama_sidebar',                    "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/reclama-sidebar.jpg");