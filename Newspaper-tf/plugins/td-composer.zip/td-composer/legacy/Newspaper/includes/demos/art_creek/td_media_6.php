<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_dark_bg_2',               "http://demo_content.tagdiv.com/Newspaper_6/art_creek/td-dark-bg-2.jpg");
td_demo_media::add_image_to_media_gallery('td_dark_bg_3',               "http://demo_content.tagdiv.com/Newspaper_6/art_creek/td-dark-bg-3.jpg");