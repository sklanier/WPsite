<?php
td_demo_media::add_image_to_media_gallery('td_pic_1', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/120.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/119.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/118.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/117.jpg');

