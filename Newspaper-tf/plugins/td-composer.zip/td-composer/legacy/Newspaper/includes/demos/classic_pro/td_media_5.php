<?php
td_demo_media::add_image_to_media_gallery('td_pic_17', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/17.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_18', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/18.jpg');

td_demo_media::add_image_to_media_gallery('td_ad_custom', 'https://cloud.tagdiv.com/demos/Newspaper/classic_pro/media/rec.png');