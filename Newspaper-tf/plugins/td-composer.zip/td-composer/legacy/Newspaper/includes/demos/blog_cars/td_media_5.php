<?php

// ads

td_demo_media::add_image_to_media_gallery('td_blog_cars_header_ad',               "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/banner-header.png");
td_demo_media::add_image_to_media_gallery('td_blog_cars_post_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/banner-post.jpg");
td_demo_media::add_image_to_media_gallery('td_blog_cars_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/banner-sidebar.jpg");

