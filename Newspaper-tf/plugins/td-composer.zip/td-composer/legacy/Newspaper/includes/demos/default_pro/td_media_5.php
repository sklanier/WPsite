<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/login-mod.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/np10blue-white.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_9', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/newspaper-rec728.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'http://demo_content.tagdiv.com/Newspaper_6/default_pro/newspaper-rec300@2x.jpg');

